import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PhysicalTraining } from 'src/app/models/physical-training.model';
import { PhysicalTrainingService } from 'src/app/services/physical-training.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-adminaddtraining',
  templateUrl: './adminaddtraining.component.html',
  styleUrls: ['./adminaddtraining.component.css']
})
export class AdminaddtrainingComponent implements OnInit {

  new_training: PhysicalTraining = {
    TrainingName: "",
    Description: "",
    TrainerName: "",
    Location: "",
    IsIndoor: true,
    Fee: null,
    FocusArea: "",
    PhysicalRequirements: "", 
  };

  errorMessage:string='';
  formSubmitted: boolean = false;
  showPopup: boolean = false;
  constructor(private addPhysicalTrainingService: PhysicalTrainingService, private router: Router) { } 

  ngOnInit(): void {
  }

  isValid(): boolean {
     if(this.new_training.TrainingName.trim() && this.new_training.Description.trim() && this.new_training.TrainerName.trim() && this.new_training.Location.trim() && this.new_training.IsIndoor !== null && this.new_training.Fee !== null && this.new_training.FocusArea.trim() && this.new_training.PhysicalRequirements.trim() && this.formSubmitted){
      return true;
     }
     return false;
  }

  adminAddTraining(): void {
    this.formSubmitted = true;  
    if (this.isValid()) {
      this.errorMessage='';
      this.addPhysicalTrainingService.addPhysicalTraining(this.new_training).subscribe({
        next: () => {
          this.formSubmitted=false;
          this.showPopup = true; // Show success popup
        },
        error:(err)=>{
         this.errorMessage=err.error.message;
         this.formSubmitted=false;
        }
      });
    } 
   
  }



  closePopup(form:NgForm): void {
    this.showPopup = false;
    this.formSubmitted=false;
    form.resetForm();
    this.new_training = {
      TrainingName: "",
      Description: "",
      TrainerName: "",
      Location: "",
      IsIndoor: true,
      Fee: null,
      FocusArea: "",
      PhysicalRequirements: "", 
    };
  }

}