import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PhysicalTraining } from 'src/app/models/physical-training.model';
import { PhysicalTrainingService } from 'src/app/services/physical-training.service';

@Component({
  selector: 'app-adminviewtraining',
  templateUrl: './adminviewtraining.component.html',
  styleUrls: ['./adminviewtraining.component.css']
})
export class AdminviewtrainingComponent implements OnInit {

  trainings:PhysicalTraining[] = [];
  currentIdDelete:string;
  searchTerm:string;
  filteredTrainings:PhysicalTraining[] = [];
  viewMode:string = 'tableview';
  showPopup=false;
  currentPage:number=1;
  itemsPerPage:number=20;
  errorMessage:string='';

  constructor(private trainingService: PhysicalTrainingService, private router: Router) { }

  ngOnInit(): void {
    this.trainingService.getAllPhysicalTrainings().subscribe((data) => {
      this.trainings = data;
      this.filteredTrainings = data;
    });
  }

  openDeletePopup(id: string) {
    this.showPopup = true;
    this.currentIdDelete = id;
  }

  closePopup() {
    this.showPopup = false;
  }

  editRoute(PhysicalTrainingId: number) {
    this.router.navigate([`adminedittraining/${PhysicalTrainingId}`]);
  }

  confirmDelete(){
    this.trainingService.deletePhysicalTraining(this.currentIdDelete).subscribe({next: ()=>{
      this.showPopup = false;
      this.errorMessage='';
      this.trainingService.getAllPhysicalTrainings().subscribe((data) => {
        this.trainings = data;
        this.filteredTrainings = data;
      })
    },
    error: (errorResponse) => {
      this.errorMessage = errorResponse.error.message;
      this.showPopup = false;
    }
    });
  }

  filterSearch() {
    this.filteredTrainings = this.trainings.filter(r => r.TrainingName.toLowerCase().includes(this.searchTerm.toLowerCase()));
  }

  get paginatedPosts() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredTrainings.slice(startIndex, endIndex);
  }

  changePage(page:number)
  {
    if(page>=1 && page<=this.totalPages)
    {
      this.currentPage=page;
    }
  }

  get totalPages()
  {
    return Math.ceil(this.filteredTrainings.length/this.itemsPerPage);
  }
}