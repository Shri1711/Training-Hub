import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PhysicalTrainingRequest } from 'src/app/models/physical-training-request.model';
import { AuthService } from 'src/app/services/auth.service';
import { PhysicalTrainingService } from 'src/app/services/physical-training.service';

@Component({
  selector: 'app-useraddrequest',
  templateUrl: './useraddrequest.component.html',
  styleUrls: ['./useraddrequest.component.css']
})
export class UseraddrequestComponent implements OnInit {
  formSubmitted:boolean=false;
  errorMessage:string='';
  showPopup: boolean = false;

  physicalTrainingRequest: PhysicalTrainingRequest = {
    PhysicalTrainingRequestId:0,
    UserId: 0,  
    PhysicalTrainingId: 0,
    RequestDate: new Date().toISOString(),
    Status: 'Pending',
    HealthConditions: '',
    FitnessGoals: '',
    Comments: ''
    
  };
  constructor(private physicaltrainingService:PhysicalTrainingService,private router:Router,private authService:AuthService,private route:ActivatedRoute) { }

  ngOnInit(): void {
      this.route.params.subscribe(p=>{this.physicalTrainingRequest.PhysicalTrainingId=p.id;
      });
  }

  userviewappliedrequest()
  {
    this.router.navigate(['/userviewappliedrequest']);
  }

  isValid():boolean{
     if(this.physicalTrainingRequest.HealthConditions.trim() && this.physicalTrainingRequest.FitnessGoals.trim())
     {
      return true;
     }
     return false;
  }

  addTrainingRequest()
  {
    this.formSubmitted=true;
    console.log(this.isValid());
    if(this.isValid())
    {
        console.log(this.physicalTrainingRequest.PhysicalTrainingId);
        this.physicalTrainingRequest.UserId=this.authService.getUserId();
        this.physicaltrainingService.addPhysicalTrainingRequest(this.physicalTrainingRequest).subscribe({
            next: () => {
                this.showPopup=true; // Show success popup
            },
            error:(err)=>{
              this.errorMessage=err.error.message;
              console.log(this.errorMessage);
              this.formSubmitted=false;
             }
        });
    }
  }


  closePopup(): void {
    this.showPopup = false;
    this.formSubmitted=false;
    this.router.navigate(['/userviewappliedrequest']);
  }

}



