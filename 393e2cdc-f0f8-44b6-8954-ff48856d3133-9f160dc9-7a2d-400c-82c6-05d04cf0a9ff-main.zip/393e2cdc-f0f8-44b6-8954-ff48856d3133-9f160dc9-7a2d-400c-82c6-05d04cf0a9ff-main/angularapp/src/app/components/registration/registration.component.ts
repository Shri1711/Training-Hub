import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})

export class RegistrationComponent implements OnInit {
  user: User={
    UserId:0,
    Email:'',
    Password:'',
    Username:'',
    MobileNumber:'',
    UserRole:''
  };
  confirmPassword:string='';
  errorMessage:string='';
  formSubmitted=false;
  secretKey:string='admin@training';
  enteredkey:string='';

  constructor(private authService:AuthService,private router:Router) { }

  register()
  {
    this.formSubmitted=true;

    if(this.user.Email.trim() && this.user.Password.trim() && this.user.Username.trim() && this.user.MobileNumber.trim() && this.user.UserRole.trim())
    {
      // If role is Admin, validate the secret key
      if (this.user.UserRole === 'Admin' && this.enteredkey !== this.secretKey) {
        this.errorMessage = 'Invalid secret key for Admin.';
        this.formSubmitted = false;
        return;
      }


      this.authService.register(this.user).subscribe({
        next:()=>{
          alert("Registration successful");
          this.router.navigate(['/login']);
       },
       error:(err)=>{
        this.errorMessage=err.error.message || 'User already exists.';
        this.formSubmitted=false;
       }
      });
    }
  }

  checkPassword(): boolean
  {
    return (this.user.Password!=this.confirmPassword);
  }

  ngOnInit(): void {
  }

}