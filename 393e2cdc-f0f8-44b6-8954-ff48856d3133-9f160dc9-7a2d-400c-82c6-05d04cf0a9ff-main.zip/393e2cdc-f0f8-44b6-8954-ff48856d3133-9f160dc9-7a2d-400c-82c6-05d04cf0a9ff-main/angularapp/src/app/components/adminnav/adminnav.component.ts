import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-adminnav',
  templateUrl: './adminnav.component.html',
  styleUrls: ['./adminnav.component.css']
})
export class AdminnavComponent implements OnInit {
 
  constructor(private authService:AuthService, private router:Router) { }
  userName:string=this.authService.getUsername();
  userRole:string=this.authService.getUserRole();
  dropDrownValue:string;
  showLogOutPopup:boolean = false;

  ngOnInit(): void {
    
  }

  logoutpopup():void{
      this.showLogOutPopup = true;
  }

  logout():void{
    
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  closePopup(){
    this.showLogOutPopup = false;
  }
}
