import { Component, OnInit } from '@angular/core';
import { PhysicalTrainingRequest } from 'src/app/models/physical-training-request.model';
import { PhysicalTrainingService } from 'src/app/services/physical-training.service';

@Component({
  selector: 'app-adminviewappliedrequest',
  templateUrl: './adminviewappliedrequest.component.html',
  styleUrls: ['./adminviewappliedrequest.component.css']
})
export class AdminviewappliedrequestComponent implements OnInit {
  trainingRequests: PhysicalTrainingRequest[] = [];
  filteredRequests: PhysicalTrainingRequest[] = [];
  searchTerm: string = '';
  statusFilter: string = '';
  viewMode: string = 'table';
  currentPage: number = 1;
  itemsPerPage: number = 12; 

  constructor(private trainingService: PhysicalTrainingService) { }

  ngOnInit(): void {
    this.getAllTrainingRequests();
  }

  getAllTrainingRequests(): void {
    this.trainingService.getAllPhysicalTrainingRequests().subscribe(
      (data: PhysicalTrainingRequest[]) => {
        console.log(data);
        this.trainingRequests = data;
        this.filteredRequests = data;
      },
      (error) => {
        console.error('Error fetching training requests', error);
      }
    );
  }

  search(): void {
    this.filteredRequests = [...this.trainingRequests].filter(request =>
      request.PhysicalTraining.TrainingName.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  filterByStatus(): void {
    if (this.statusFilter === 'All') {
      this.filteredRequests = this.trainingRequests;
    } else {
      this.filteredRequests = this.trainingRequests.filter(request =>
        request.Status.includes(this.statusFilter)
      );
    }
  }

  approveRequest(requestId: number): void {
    const updatedRequest = this.trainingRequests.find(request => request.PhysicalTrainingRequestId === requestId);
    if (updatedRequest) {
      updatedRequest.Status = 'Approved';
      this.trainingService.updatePhysicalTrainingRequest(requestId.toString(), updatedRequest).subscribe(
        (response) => {
          console.log('Request approved successfully', response);
          this.getAllTrainingRequests();
        },
        (error) => {
          console.error('Error approving request', error);
        }
      );
    }
  }

  rejectRequest(requestId: number): void {
    const updatedRequest = this.trainingRequests.find(request => request.PhysicalTrainingRequestId === requestId);
    if (updatedRequest) {
      updatedRequest.Status = 'Rejected';
      this.trainingService.updatePhysicalTrainingRequest(requestId.toString(), updatedRequest).subscribe(
        (response) => {
          console.log('Request rejected successfully', response);
          this.getAllTrainingRequests();
        },
        (error) => {
          console.error('Error rejecting request', error);
        }
      );
    }
  }

  get paginatedPosts() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredRequests.slice(startIndex, endIndex);
  }

  changePage(page: number) {
    this.currentPage = page;
  }

  get totalPages() {
    return Math.ceil(this.filteredRequests.length / this.itemsPerPage);
  }
}