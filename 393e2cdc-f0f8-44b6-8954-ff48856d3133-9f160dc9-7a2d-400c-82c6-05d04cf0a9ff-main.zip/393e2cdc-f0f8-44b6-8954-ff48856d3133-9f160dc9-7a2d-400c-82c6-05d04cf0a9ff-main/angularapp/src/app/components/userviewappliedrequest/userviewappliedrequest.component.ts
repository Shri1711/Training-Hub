import { Component, OnInit } from '@angular/core';
import { PhysicalTrainingRequest } from 'src/app/models/physical-training-request.model';
import { PhysicalTrainingService } from 'src/app/services/physical-training.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-userviewappliedrequest',
  templateUrl: './userviewappliedrequest.component.html',
  styleUrls: ['./userviewappliedrequest.component.css']
})
export class UserviewappliedrequestComponent implements OnInit {

  trainingRequests: PhysicalTrainingRequest[] = [];
  filteredRequests: PhysicalTrainingRequest[] = [];
  searchTerm: string = '';
  showDeletePopup: boolean = false;
  requestIdToDelete: number | null = null;
  currentPage: number = 1; 
  itemsPerPage: number = 10; 

  constructor(private trainingService: PhysicalTrainingService, private authService: AuthService) { }

  ngOnInit(): void {
    const userId = this.authService.getUserId();
    if (userId !== null) {
      this.getUserTrainingRequests(userId.toString());
    } else {
      console.error('User ID is null');
    }
  }

  getUserTrainingRequests(userId: string): void {
    this.trainingService.getPhysicalTrainingRequestsByUserId(userId).subscribe(
      (data: PhysicalTrainingRequest[]) => {
        this.trainingRequests = data;
        this.filteredRequests = data;
      },
      (error) => {
        console.error('Error fetching training requests', error);
      }
    );
  }

  search(): void {
    this.filteredRequests = [...this.trainingRequests].filter(request =>
      request.PhysicalTraining.TrainingName.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  confirmDelete(requestId: number): void {
    this.requestIdToDelete = requestId;
    this.showDeletePopup = true;
  }

  cancelDelete(): void {
    this.showDeletePopup = false;
    this.requestIdToDelete = null;
  }

  deleteRequest(): void {
    if (this.requestIdToDelete !== null) {
      this.trainingService.deletePhysicalTrainingRequest(this.requestIdToDelete.toString()).subscribe(
        (response) => {
          console.log('Request deleted successfully', response);
          const userId = this.authService.getUserId();
          if (userId !== null) {
            this.getUserTrainingRequests(userId.toString());
          }
          this.cancelDelete();
        },
        (error) => {
          console.error('Error deleting request', error);
        }
      );
    }
  }

  get paginatedRequests() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredRequests.slice(startIndex, endIndex);
  }

  changePage(page: number) {
    this.currentPage = page;
  }

  get totalPages() {
    return Math.ceil(this.filteredRequests.length / this.itemsPerPage);
  }
}
