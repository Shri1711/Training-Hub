import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  isAuthenticated=false;
  userRole:string | null=null;
  constructor(private authService:AuthService) { }

  ngOnInit(): void {
     // Subscribe to authentication status
     this.authService.isAuthenticated$.subscribe((auth)=>{
      this.isAuthenticated=auth;
    });

    // Subscribe to user role updates
    this.authService.userRole$.subscribe((role)=>{
      this.userRole=role;
    });
  }

}
