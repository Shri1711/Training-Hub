import { Component, OnInit } from '@angular/core';
import { Feedback } from 'src/app/models/feedback.model';
import { AuthService } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-userviewfeedback',
  templateUrl: './userviewfeedback.component.html',
  styleUrls: ['./userviewfeedback.component.css']
})
export class UserviewfeedbackComponent implements OnInit {
  feedbacks: Feedback[] = [];
  paginatedFeedbacks: Feedback[] = []; 
  userId: number;
  showPopup: boolean = false;
  feedbackToDelete: number | null = null;
  currentPage: number = 1; 
  itemsPerPage: number = 10; 

  constructor(private feedbackService: FeedbackService, private authService: AuthService) { }

  ngOnInit(): void {
    this.userId = this.authService.getUserId();
    this.loadFeedbacks();
  }

  loadFeedbacks() {
    this.feedbackService.getAllFeedbacksByUserId(this.userId).subscribe(
      (data: Feedback[]) => {
        this.feedbacks = data;
        this.paginateFeedbacks(); 
      },
      error => {
        console.error("Error fetching the feedback", error);
      }
    );
  }

  openDeletePopup(feedbackId: number) {
    this.feedbackToDelete = feedbackId;
    this.showPopup = true;
  }

  closePopup() {
    this.showPopup = false;
    this.feedbackToDelete = null;
  }

  confirmDelete() {
    if (this.feedbackToDelete !== null) {
      this.feedbackService.deleteFeedback(this.feedbackToDelete).subscribe(
        () => {
          this.loadFeedbacks(); // Reload feedbacks after deletion
          this.closePopup();
        },
        error => {
          if (error.status === 200) {
            console.log('Feedback deleted successfully.');
          } else {
            console.error('Error deleting feedback', error);
          }
          this.closePopup();
          this.loadFeedbacks();
        }
      );
    }
  }

  paginateFeedbacks(): void {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedFeedbacks = this.feedbacks.slice(startIndex, endIndex);
  }

  changePage(page: number): void {
    this.currentPage = page;
    this.paginateFeedbacks();
  }

  get totalPages(): number {
    return Math.ceil(this.feedbacks.length / this.itemsPerPage);
  }
}
