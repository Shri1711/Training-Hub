import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from 'src/app/models/login.model';
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:Login={
    Email:'',
    Password:''
  }
  errorMessage: string = '';
  formSubmitted:boolean=false;

  constructor(private authService:AuthService,private router:Router) { }

  ngOnInit(): void {
  }

  
  onSubmit() {
    this.formSubmitted=true;
    if(this.user.Email.trim() && this.user.Password.trim())
    {
      this.authService.login(this.user).subscribe({
        next:()=>{
          alert("Login successful");
          this.router.navigate(['/home']);
       },
       error:(err)=>{
        this.errorMessage='*Invalid email or password.';
        this.formSubmitted=false;
       }
      });
    }
  }


  
}
