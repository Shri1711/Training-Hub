import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const userRole = this.authService.getUserRole();
    // console.log("AuthGuard Role Check:"+userRole);
    if (!this.authService.isLoggedIn()) {
      // Not logged in, redirect to login page
      this.router.navigate(['/login']);
      return false;
    }

    // To Check role-based access
    if (route.data.roles && route.data.roles.indexOf(userRole) === -1) {
      // Role not authorized, redirect to error page
      this.router.navigate(['/error']);
      return false;
    }

    return true;
  } 
}