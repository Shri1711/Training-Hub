import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PhysicalTrainingRequest } from 'src/app/models/physical-training-request.model';
import { PhysicalTraining } from 'src/app/models/physical-training.model';
import { AuthService } from 'src/app/services/auth.service';
import { PhysicalTrainingService } from 'src/app/services/physical-training.service';

@Component({
  selector: 'app-userviewtraining',
  templateUrl: './userviewtraining.component.html',
  styleUrls: ['./userviewtraining.component.css']
})
export class UserviewtrainingComponent implements OnInit {

  trainings: PhysicalTraining[] = [];
  filteredTrainings: PhysicalTraining[] = [];
  appliedTrainings: PhysicalTrainingRequest[] = [];
  showPopup: boolean = false;
  UserId: number;
  searchTerm: string = '';
  currentPage: number = 1; // Added for pagination
  itemsPerPage: number = 10; // Added for pagination

  constructor(private trainingService: PhysicalTrainingService, private router: Router, private authService: AuthService) { }

  ngOnInit(): void {
    this.UserId = this.authService.getUserId();
    if (this.UserId !== null) {
      this.fetchAppliedTrainings();
    } else {
      console.error('User ID is null');
    }
    this.fetchTrainings();
  }

  fetchTrainings(): void {
    this.trainingService.getAllPhysicalTrainings().subscribe((data) => {
      this.trainings = data;
      this.filteredTrainings = data;
    });
  }

  fetchAppliedTrainings(): void {
    this.trainingService.getPhysicalTrainingRequestsByUserId(this.UserId.toString()).subscribe((data) => {
      this.appliedTrainings = data;
    });
  }

  filterSearch(): void {
    this.filteredTrainings = this.trainings.filter(r =>
      r.TrainingName.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      r.Description.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      r.FocusArea.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  applyTraining(trainingId: number): void {
    this.router.navigate([`/useraddrequest/${trainingId}`]);
  }

  isTrainingApplied(trainingId: number): boolean {
    return this.appliedTrainings.some(request => request.PhysicalTrainingId === trainingId);
  }

  get paginatedTrainings(): PhysicalTraining[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredTrainings.slice(startIndex, endIndex);
  }

  changePage(page: number): void {
    this.currentPage = page;
  }

  get totalPages(): number {
    return Math.ceil(this.filteredTrainings.length / this.itemsPerPage);
  }
}
