import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {
  isAuthenticated=false;
  userRole:string | null=null;
  constructor(private authService:AuthService) { }

  ngOnInit(): void {
     // Subscribe to authentication status
     this.authService.isAuthenticated$.subscribe((auth)=>{
      this.isAuthenticated=auth;
    });

    // Subscribe to user role updates
    this.authService.userRole$.subscribe((role)=>{
      this.userRole=role;
    });
  }

}
