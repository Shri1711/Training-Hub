import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PhysicalTraining } from 'src/app/models/physical-training.model';
import { PhysicalTrainingService } from 'src/app/services/physical-training.service';

@Component({
  selector: 'app-adminedittraining',
  templateUrl: './adminedittraining.component.html',
  styleUrls: ['./adminedittraining.component.css']
})
export class AdminedittrainingComponent implements OnInit {
  updated_training: PhysicalTraining;
  trainingId: string;
  formSubmitted: boolean = false;
  showPopup: boolean = false;
  errorMessage:string='';

  constructor(private physicalTrainingService: PhysicalTrainingService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      this.trainingId = params.id;
      this.physicalTrainingService.getPhysicalTrainingById(this.trainingId).subscribe((data) => {
        this.updated_training= data;
      });
    });
  }


  isValid(): boolean {
  return !!(this.updated_training.TrainingName.trim() && this.updated_training.Description.trim() && this.updated_training.TrainerName.trim() && this.updated_training.Location.trim() && this.updated_training.IsIndoor !== null && this.updated_training.Fee !== null && this.updated_training.FocusArea.trim() && this.updated_training.PhysicalRequirements.trim());
  } 


  adminEditTraining(): void {
    this.formSubmitted = true;
    
    if (this.isValid()) {
      this.errorMessage='';
      this.physicalTrainingService.updatePhysicalTraining(this.trainingId, this.updated_training).subscribe({
        next: () => {
            this.showPopup = true; // Show success popup
        },
        error: (err) => {
            this.errorMessage = err.error.message;
            console.log(this.errorMessage);
            this.formSubmitted = false;
        }
    });
    }
  }

  adminViewTraining(): void {
    this.router.navigate(['/adminviewtraining']);
  }


  closePopup(): void {
    this.showPopup = false;
    this.formSubmitted=false;
    this.router.navigate(['/adminviewtraining']);
  }
}



 

  