import { Component, OnInit } from '@angular/core';

import { Feedback } from 'src/app/models/feedback.model';
import { AuthService } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-useraddfeedback',
  templateUrl: './useraddfeedback.component.html',
  styleUrls: ['./useraddfeedback.component.css']
})
export class UseraddfeedbackComponent implements OnInit {
  new_feedback: Feedback = {
    UserId: 0, // Set appropriate default value
    FeedbackText: '',
    Date: new Date()
  };
  formSubmitted: boolean = false;
  showPopup: boolean = false;

  constructor(private feedbackService: FeedbackService,private authService:AuthService) { }

  ngOnInit(): void {
  }

  addUserFeedback() {
    this.formSubmitted = true;
    if (this.new_feedback.FeedbackText.trim()) {
      this.new_feedback.UserId=this.authService.getUserId();
      this.feedbackService.sendFeedback(this.new_feedback).subscribe(response => {
        
        console.log('Feedback submitted successfully', response);
        this.new_feedback = {
          UserId: 0, //default reset
          FeedbackText: '',
          Date: new Date()
        };
        this.formSubmitted = false; //reset
        this.showPopup = true; // for success popup
      }, error => {
        console.error('Error submitting feedback', error);
      });
    }
  }

  closePopup() {
    this.showPopup = false;
  }
}