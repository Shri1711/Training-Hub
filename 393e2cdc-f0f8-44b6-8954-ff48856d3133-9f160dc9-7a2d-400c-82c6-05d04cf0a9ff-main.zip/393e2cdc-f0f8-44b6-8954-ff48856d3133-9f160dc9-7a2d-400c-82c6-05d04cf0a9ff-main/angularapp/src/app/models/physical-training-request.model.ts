import { User } from "./user.model";
import { PhysicalTraining } from "./physical-training.model";
export interface PhysicalTrainingRequest
{
    PhysicalTrainingRequestId?:number;
    UserId:number;
    PhysicalTrainingId:number;
    RequestDate:string;
    Status:string;
    HealthConditions:string;
    FitnessGoals:string;
    Comments?:string;
    User?:User;
    PhysicalTraining?:PhysicalTraining;
}