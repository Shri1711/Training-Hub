export class Login {
    Email:string;
    Password:string;
}