import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Feedback } from '../models/feedback.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  public baseUrl=environment.baseUrl;
  constructor(private http:HttpClient) { }


   // Method to send feedback to the server 
  sendFeedback(feedback:Feedback):Observable<Feedback>{
      return this.http.post<Feedback>(`${this.baseUrl}/api/feedback`, feedback);
  }

  // Retrieves all feedbacks submitted by a specific user
  getAllFeedbacksByUserId(userId:number):Observable<Feedback[]>{
       return this.http.get<Feedback[]>(`${this.baseUrl}/api/feedback/user/${userId}`);
  }
  
  // Delete a feedback with a specific ID
  deleteFeedback(feedbackId:number):Observable<void>{
   return this.http.delete<void>(`${this.baseUrl}/api/feedback/${feedbackId}`);
  }

  // To fetch all the feedbacks from the server
  getFeedbacks():Observable<Feedback[]>{
   return this.http.get<Feedback[]>(`${this.baseUrl}/api/feedback`);
  }

}
