import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user.model';
import { Login } from '../models/login.model';
import {tap} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  public baseUrl=environment.baseUrl;
  public tokenKey='jwtToken';
  public roleKey='userRole';
  public userIdKey='userId';
  public usernameKey='username';

  private isAuthenticatedSubject=new BehaviorSubject<boolean>(this.hasToken());
  private userRoleSubject=new BehaviorSubject<string | null>(this.getUserRole());
  private usernameSubject=new BehaviorSubject<string | null>(this.getUsername());

  isAuthenticated$=this.isAuthenticatedSubject.asObservable();
  userRole$=this.userRoleSubject.asObservable();
  username$=this.usernameSubject.asObservable();
  
  constructor(private http:HttpClient) { }

  register(user:User):Observable<any>{
    return this.http.post(`${this.baseUrl}/api/register`,user);
  }


  login(credentials: Login): Observable<any> {
    return this.http.post(`${this.baseUrl}/api/login`, credentials).pipe(
      tap((response: any) => {
        // console.log(JSON.stringify(response));
        if (response.token) {
          localStorage.setItem(this.tokenKey,response.token);
          const token = localStorage.getItem(this.tokenKey);
          // console.log('Retrieved Token:', token);
          const tokenPart = response.token.split('.');
          let payload = JSON.parse(atob(tokenPart[1]));
          // console.log(JSON.stringify(payload));
          const userId = Number(payload.nameid);
          const email = payload.email;
          const username = payload.name;
          const userRole = payload.role;

          localStorage.setItem(this.roleKey, userRole);
          localStorage.setItem(this.userIdKey, userId.toString());
          localStorage.setItem(this.usernameKey, username);

          this.isAuthenticatedSubject.next(true);
          this.userRoleSubject.next(userRole);
          this.usernameSubject.next(username);

        }
      })
    );
  }


  logout():void{
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.roleKey);
    localStorage.removeItem(this.userIdKey);
    this.isAuthenticatedSubject.next(false);
    this.userRoleSubject.next(null);
  }

  getToken():string | null{
    return localStorage.getItem(this.tokenKey);
  }

  getUserRole():string | null{
    return localStorage.getItem(this.roleKey);
  }

  getUsername():string|null{
    return localStorage.getItem(this.usernameKey);
  }

  getUserId():number | null {
    const userId=localStorage.getItem(this.userIdKey);
    return userId? parseInt(userId,10):null;
  }

  isLoggedIn():boolean{
    return !!this.getToken();
  }

  private hasToken():boolean{
    return this.getToken()!==null;
  }
}
