import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { PhysicalTraining } from '../models/physical-training.model';
import { PhysicalTrainingRequest } from '../models/physical-training-request.model';
import { environment } from 'src/environments/environment';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class PhysicalTrainingService {
  
  public baseUrl=environment.baseUrl;
  constructor(private http:HttpClient,private authService:AuthService) { }

  // private getAuthHeaders(): HttpHeaders{
  //   //const token=localStorage.getItem('authToken');
  //   const token=this.authService.getToken();
  //   console.log(token);
  //   return new HttpHeaders({
  //     Authorization:'Bearer ${token}',
  //     'Content-Type':'application/json'
  //   });
  // }


  // Fetches all physical training session from the server
  getAllPhysicalTrainings():Observable<PhysicalTraining[]>{
    return this.http.get<PhysicalTraining[]>(`${this.baseUrl}/api/physicalTraining`);
  }

  // Retrieves a specific physical training session by its ID.

  getPhysicalTrainingById(trainingId:string):Observable<PhysicalTraining>
  {
    console.log("insideeee...")
    return this.http.get<PhysicalTraining>(`${this.baseUrl}/api/physicalTraining/${trainingId}`);
  }

  // Adds a new physical training session.
  addPhysicalTraining(training:PhysicalTraining):Observable<PhysicalTraining>
  {
    return this.http.post<PhysicalTraining>(`${this.baseUrl}/api/physicalTraining`,training);
  }

  // Update an existing physical training session
  updatePhysicalTraining(trainingId:string,training:PhysicalTraining):Observable<PhysicalTraining>
  {
    return this.http.put<PhysicalTraining>(`${this.baseUrl}/api/physicalTraining/${trainingId}`,training);
  }

  // Delete a physical training session by its ID.
  deletePhysicalTraining(trainingId:string):Observable<void>{
    return this.http.delete<void>(`${this.baseUrl}/api/physicalTraining/${trainingId}`);
  }


   // Fetches all physical training request session from the server
  getAllPhysicalTrainingRequests():Observable<PhysicalTrainingRequest[]>
  {
    return this.http.get<PhysicalTrainingRequest[]>(`${this.baseUrl}/api/physical-training-request`);
  }

   // Retrieves a specific physical training request session by its ID.
  getPhysicalTrainingRequestsByUserId(userId:string):Observable<PhysicalTrainingRequest[]>
  {
    const numericUserId = Number(userId);
    return this.http.get<PhysicalTrainingRequest[]>(`${this.baseUrl}/api/physical-training-request/${numericUserId}`);
  }

  // Adds a new physical training request session.
  addPhysicalTrainingRequest(request:PhysicalTrainingRequest):Observable<PhysicalTrainingRequest>
  {
    return this.http.post<PhysicalTrainingRequest>(`${this.baseUrl}/api/physical-training-request`,request);
  }

  // Update an existing physical training request session
  updatePhysicalTrainingRequest(requestId:string,request:PhysicalTrainingRequest):Observable<PhysicalTrainingRequest>
  {
    return this.http.put<PhysicalTrainingRequest>(`${this.baseUrl}/api/physical-training-request/${requestId}`,request);
  }

  // Delete a physical training request session by its ID.
  deletePhysicalTrainingRequest(requestId:string):Observable<void>
  {
    return this.http.delete<void>(`${this.baseUrl}/api/physical-training-request/${requestId}`);
  }
}














































 

 
