import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminaddtrainingComponent } from './components/adminaddtraining/adminaddtraining.component';
import { ErrorComponent } from './components/error/error.component';
import { HomeComponent } from './components/home/home.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { LoginComponent } from './components/login/login.component';
import { AdminviewtrainingComponent } from './components/adminviewtraining/adminviewtraining.component';
import { AdminedittrainingComponent } from './components/adminedittraining/adminedittraining.component';
import { AdminviewappliedrequestComponent } from './components/adminviewappliedrequest/adminviewappliedrequest.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { UserviewtrainingComponent } from './components/userviewtraining/userviewtraining.component';
import { UseraddrequestComponent } from './components/useraddrequest/useraddrequest.component';
import { UserviewappliedrequestComponent } from './components/userviewappliedrequest/userviewappliedrequest.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { AuthGuard } from './components/authguard/auth.guard';

const routes: Routes = [
  {path: 'home',component: HomeComponent},
  {path: 'registration',component: RegistrationComponent},
  {path: 'login',component: LoginComponent},
  {path: 'adminaddtraining',component: AdminaddtrainingComponent, canActivate: [AuthGuard], data: { roles: ['Admin'] } },
  {path: 'adminviewtraining',component: AdminviewtrainingComponent,  canActivate: [AuthGuard], data: { roles: ['Admin'] } },
  {path: 'adminedittraining/:id',component:AdminedittrainingComponent,  canActivate: [AuthGuard], data: { roles: ['Admin'] } },
  {path: 'adminviewappliedrequest',component: AdminviewappliedrequestComponent,  canActivate: [AuthGuard], data: { roles: ['Admin'] } },
  {path: 'adminviewfeedback',component: AdminviewfeedbackComponent,  canActivate: [AuthGuard], data: { roles: ['Admin'] } },
  {path: 'userviewtraining',component: UserviewtrainingComponent,  canActivate: [AuthGuard], data: { roles: ['User'] } },
  {path: 'useraddrequest/:id',component: UseraddrequestComponent,  canActivate: [AuthGuard], data: { roles: ['User'] } },
  {path: 'userviewappliedrequest',component: UserviewappliedrequestComponent, canActivate: [AuthGuard], data: { roles: ['User'] } },
  {path: 'useraddfeedback',component: UseraddfeedbackComponent, canActivate: [AuthGuard], data: { roles: ['User'] } },
  {path: 'userviewfeedback',component:UserviewfeedbackComponent,  canActivate: [AuthGuard], data: { roles: ['User'] } },
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'**', component: ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
