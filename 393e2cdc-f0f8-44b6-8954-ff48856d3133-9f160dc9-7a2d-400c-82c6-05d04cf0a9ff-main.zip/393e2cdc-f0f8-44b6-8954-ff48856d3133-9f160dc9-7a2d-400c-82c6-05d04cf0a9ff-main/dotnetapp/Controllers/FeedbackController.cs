using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using dotnetapp.Data;
using dotnetapp.Exceptions;
using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/feedback")]
    public class FeedbackController : ControllerBase
    {
        private readonly FeedbackService _feedbackService;
        private readonly ILogger<FeedbackController> _logger;

        public FeedbackController(FeedbackService feedbackService, ILogger<FeedbackController> logger ){
            _feedbackService=feedbackService;
            _logger = logger;
        }

      
        // Method responsible to retrieve all feedbacks
        [HttpGet]
        [Authorize(Roles="Admin")]
        public async Task<ActionResult<IEnumerable<Feedback>>> GetAllFeedbacks(){
          try{
            var feedbacks=await _feedbackService.GetAllFeedbacks();
            return Ok(feedbacks);
          }
          catch(PhysicalTrainingException ex){
            _logger.LogError(ex, "Error retrieving all feedbacks");
            return StatusCode(500,new {message=ex.Message});
          }
        } 


         // Method responsible to retrieve all feedbacks by userId
        [HttpGet("user/{userId}")]
        [Authorize(Roles="User")]
        public async Task<ActionResult<IEnumerable<Feedback>>> GetFeedbacksByUserId(int userId){
          try{
            var feedbacks_ById= await _feedbackService.GetFeedbacksByUserId(userId);
            return Ok(feedbacks_ById);
          }
          catch(PhysicalTrainingException ex){
            _logger.LogError(ex, $"Error retrieving feedbacks for user ID {userId}");
            return StatusCode(500,new {message=ex.Message});
          }
        }

        // Method responsible for adding a new feedback
        [HttpPost]
        [Authorize(Roles="User")]
        public async Task<ActionResult>AddFeedback([FromBody] Feedback feedback){
          Console.WriteLine("Feedback Data controller:"+feedback);
            try{
               bool result=await  _feedbackService.AddFeedback(feedback);
               if(result)
               {
                    return Ok(new {message="Feedback added successfully"});
               }
               else{
                    return StatusCode(400,new {message="Bad request. Invalid feedback data."});
               }
            }
            catch(PhysicalTrainingException ex){
              _logger.LogError(ex, "Error adding feedback");
              return StatusCode(404,new {message=ex.Message});
            }

        }

         //Method responsible to delete a feedback
        [HttpDelete("{feedbackId}")]
        [Authorize(Roles="User")]
        public async Task<ActionResult> DeleteFeedback(int feedbackId){
            try{
             bool feedback_deleted=await _feedbackService.DeleteFeedback(feedbackId);
             if(feedback_deleted){
               return Ok("Feedback deleted successfully");
             }
             else{
                return StatusCode(404,new {message="Cannot find any feedback"});
             }
            }

            catch(PhysicalTrainingException ex){
                _logger.LogError(ex, $"Error deleting feedback with ID {feedbackId}");
                return StatusCode(500,new {message=ex.Message});
            }

        }


        
        
    }
}