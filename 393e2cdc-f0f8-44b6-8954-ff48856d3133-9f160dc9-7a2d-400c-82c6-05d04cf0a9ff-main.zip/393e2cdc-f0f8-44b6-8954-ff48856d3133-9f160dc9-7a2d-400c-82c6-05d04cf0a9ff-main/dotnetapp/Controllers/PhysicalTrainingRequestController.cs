using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/physical-training-request")]
    public class PhysicalTrainingRequestController : ControllerBase
    {
    private readonly PhysicalTrainingRequestService _physicalTrainingRequestService;

    private readonly ILogger<PhysicalTrainingRequestController> _logger;

    // Constructor to initialize the service
    public PhysicalTrainingRequestController(PhysicalTrainingRequestService physicalTrainingRequestService, ILogger<PhysicalTrainingRequestController> logger )
    {
        _physicalTrainingRequestService = physicalTrainingRequestService;
        _logger=logger;
    }

    // Retrieves all physical training requests
    [HttpGet]
    [Authorize(Roles="Admin")]
    public async Task<ActionResult<IEnumerable<PhysicalTrainingRequest>>> GetAllPhysicalTrainingRequests()
    {
        try{
        var requests = await _physicalTrainingRequestService.GetAllPhysicalTrainingRequests();
        
        if(requests== null) 
        {
            return BadRequest(new {message="No Training present."});
        }
        return Ok(requests);
        }
        catch(Exception ex)
        {
            _logger.LogError(ex, "Error retrieving all physical training requests");
            return StatusCode(500, new { message = ex.Message });
        }
    }

    // Retrieves all physical training requests made by a specific user
    [HttpGet("{userId}")]
    [Authorize(Roles="User")]
    public async Task<ActionResult<IEnumerable<PhysicalTrainingRequest>>> GetPhysicalTrainingRequestsByUserId(int userId)
    {
        try
        {
        var requests = await _physicalTrainingRequestService.GetPhysicalTrainingRequestsByUserId(userId);
        if(requests== null || !requests.Any()) 
        {
            return BadRequest(new {message="No Training present."});
        }
        return Ok(requests);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error retrieving physical training requests for user ID {userId}");
            return StatusCode(500, new { message = ex.Message });
        }
    }

    // Adds a new physical training request
    [HttpPost]
    [Authorize(Roles="User")]
    public async Task<ActionResult> AddPhysicalTrainingRequest([FromBody] PhysicalTrainingRequest request)
    {
        try
        {
            bool added = await _physicalTrainingRequestService.AddPhysicalTrainingRequest(request);
            if (added)
            {
                return Ok(new {message="Physical training request added successfully."});  
            }
            return BadRequest(new {message="User already requested this training."}); 
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error adding physical training request");
            return StatusCode(500, new { message = ex.Message });
        }
    }

    // Updates an existing physical training request
    [HttpPut("{requestId}")]
    [Authorize(Roles="Admin,User")]
    public async Task<ActionResult> UpdatePhysicalTrainingRequest(int requestId, [FromBody] PhysicalTrainingRequest request)
    {
        try
        {
            bool updated = await _physicalTrainingRequestService.UpdatePhysicalTrainingRequest(requestId, request);
            if (updated)
            {
                return Ok(new {message="Physical training request updated successfully."});
            }
            return NotFound(new {message="Cannot find the request."});
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error updating physical training request with ID {requestId}");
            return StatusCode(500, new { message = ex.Message });
        }
    }

    // Deletes a physical training request
    [HttpDelete("{requestId}")]
    [Authorize(Roles="User")]
    public async Task<ActionResult> DeletePhysicalTrainingRequest(int requestId)
    {
        try
        {
            bool deleted = await _physicalTrainingRequestService.DeletePhysicalTrainingRequest(requestId);
            if (deleted)
            {
                return Ok(new {message="Physical training request deleted successfully."});
            }
            return NotFound(new {message="Cannot find the request."});
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, $"Error deleting physical training request with ID {requestId}");
            return StatusCode(500, new {message = ex.Message});
        }
    }

    }
}