using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/")]
    public class AuthenticationController : ControllerBase
    {
        private readonly IAuthService _authService;

        private readonly ILogger<AuthenticationController> _logger;

        public AuthenticationController(IAuthService authService, ILogger<AuthenticationController> logger )
        {
            _authService=authService;
            _logger=logger;
        }

        //Login 
        [HttpPost("login")]

        public async Task<IActionResult> Login(LoginModel model)
        {
            try{
                var (status,message)=await _authService.Login(model);
                if(status==0)
                {
                    return BadRequest(new {Message=message});
                }

                return Ok(new {token=message});
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, "Error during login");
                return StatusCode(500,new {Message=ex.Message});
            }
        }

        //Registration
        [HttpPost("register")]
        
        public async Task<IActionResult> Register([FromBody]User model)
        {
            try{
                if(!ModelState.IsValid)
                {
                    return BadRequest(new {Status="Error",Message="Invalid data"});
                }

                var(status,message)=await _authService.Registration(model,model.UserRole);
                if(status==0)
                {
                    Console.WriteLine(message);
                    return BadRequest(new {Status="Error",Message=message});
                }
                return Ok(new {message="User created successfully!"});
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, "Error during registration");
                return StatusCode(500,new {Message=ex.Message});
            }
        }

    }
}