using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Models;
using Microsoft.AspNetCore.Mvc;
using dotnetapp.Services;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;
using dotnetapp.Exceptions;
using Microsoft.Extensions.Logging;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/physicalTraining")]   
    public class PhysicalTrainingController : ControllerBase
    {
        private readonly PhysicalTrainingService _physicalTrainingService;

        private readonly ILogger<PhysicalTrainingController> _logger;

        public PhysicalTrainingController(PhysicalTrainingService physicalTrainingService, ILogger<PhysicalTrainingController> logger )
        {
            _physicalTrainingService = physicalTrainingService;
            _logger=logger;
        }

        // Retrieves all the physical training session.
        [HttpGet]
        [Authorize(Roles="Admin,User")]
        public async Task<ActionResult<IEnumerable<PhysicalTraining>>> GetAllPhysicalTrainings()
        {
            try
            {
                var physical_training = await _physicalTrainingService.GetAllPhysicalTrainings();
                if(physical_training==null)
                {
                    return StatusCode(400, new {message = "Physical trainings not found."});
                }
                return Ok(physical_training);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving all physical trainings");
                return StatusCode(500, new {message = ex.Message});
            }
        }

        // Retrieves a specific physical training session by its trainingId.

        [HttpGet("{trainingId}")]
        [Authorize(Roles="Admin")]
        public async Task<ActionResult<PhysicalTraining>> GetPhysicalTrainingById(int trainingId)
        {
            try
            {
                var physical_training = await _physicalTrainingService.GetPhysicalTrainingById(trainingId);
                if (physical_training == null)
                {
                    return StatusCode(404, new {message = "Cannot find any training."}); 
                }
                return Ok(physical_training);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error retrieving physical training with ID {trainingId}");
                return StatusCode(500, new {message = ex.Message});
            }
        }

        // Recieves the training data. Attempts to add the training.

        [HttpPost]
        [Authorize(Roles="Admin")]
        public async Task<ActionResult> AddPhysicalTraining([FromBody] PhysicalTraining training)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return StatusCode(400, new {message = "Invalid model state."});
                }
                bool result= await _physicalTrainingService.AddPhysicalTraining(training);
                if(!result)
                {
                    return StatusCode(500,new {message = "Failed to add physical training."});
                }
                return Ok(new { message = "Physical training added successfully."}); 
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding physical training");
                return StatusCode(500, new {message = ex.Message});
            }
        }

        // Receives the trainingId and updated training data in request body.Attempts to update the training.

        [HttpPut("{trainingId}")]
        [Authorize(Roles="Admin")]
        public async Task<ActionResult> UpdatePhysicalTraining(int trainingId, [FromBody] PhysicalTraining training)
        {
            try
            {
                bool result = await _physicalTrainingService.UpdatePhysicalTraining(trainingId, training);
                // if the training is not found.
                if (!result)
                {
                    return StatusCode(404,new { message = "Cannot find any training."});
                }
                return Ok(new {message = "Physical training updated successfully."});
            }
            catch(PhysicalTrainingException pte)
            {
                _logger.LogError(pte, $"Error updating physical training with ID {trainingId}");
                return StatusCode(500, new {message = pte.Message});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating physical training with ID {trainingId}");
                return StatusCode(500, new {message = ex.Message});
            }
        }

        // Receives the trainingId to be deleted. Attempts to delete training.

        [HttpDelete("{trainingId}")]
        [Authorize(Roles="Admin")]
        public async Task<ActionResult> DeletePhysicalTraining(int trainingId)
        {
            try
            {
                bool result= await _physicalTrainingService.DeletePhysicalTraining(trainingId);
                //if training is not found.
                if (!result)
                {
                    return StatusCode(404,new { message = "Cannot find any training."});
                }
                return Ok(new {message = "Physical training deleted successfully."});
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting physical training with ID {trainingId}");
                return StatusCode(500, new {message = ex.Message});
            }
        }
    }
}
