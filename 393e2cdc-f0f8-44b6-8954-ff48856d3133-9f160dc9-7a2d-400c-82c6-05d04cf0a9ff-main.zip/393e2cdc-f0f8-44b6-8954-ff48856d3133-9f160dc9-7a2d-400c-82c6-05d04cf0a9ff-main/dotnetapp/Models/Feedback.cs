using System;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations;

namespace dotnetapp.Models
{
    public class Feedback
    {
        public int FeedbackId{get; set;}
        [Required]
        public int UserId{get; set;}

        // [JsonIgnore]
        public User? User{get; set;}
        [Required]
        public string FeedbackText{get; set;}
        public DateTime Date{get; set;}
    }
}