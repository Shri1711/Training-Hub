using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations;
namespace dotnetapp.Models
{
  public class PhysicalTrainingRequest
  {
     public int PhysicalTrainingRequestId{get; set;}
     [Required]
     public int UserId{get; set;}

    // [JsonIgnore]
     public User? User{get; set;}
     [Required]
     public int PhysicalTrainingId{get; set;}

    //  [JsonIgnore]
     public PhysicalTraining? PhysicalTraining{get; set;}
     [Required]
     public string RequestDate{get; set;}
     [Required]
     public string Status{get; set;}
     [Required]
     public string HealthConditions{get; set;}
     [Required]
     public string FitnessGoals{get; set;}
     public string? Comments{get; set;}

  }
}