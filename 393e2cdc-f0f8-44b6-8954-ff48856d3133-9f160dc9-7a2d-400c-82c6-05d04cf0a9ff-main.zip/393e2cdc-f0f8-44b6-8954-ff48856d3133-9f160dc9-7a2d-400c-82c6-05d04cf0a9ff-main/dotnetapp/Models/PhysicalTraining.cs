using System.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace dotnetapp.Models{
public class PhysicalTraining
{
    public int PhysicalTrainingId {get;set;}
    [Required]
    public string TrainingName {get;set;}
    [Required]
    public string Description {get;set;}
    [Required]
    public string TrainerName {get;set;}
    [Required]
    public string Location {get;set;}
    [Required]
    public bool IsIndoor {get;set;}
    [Required]
    public decimal Fee {get;set;}
    [Required]
    public string FocusArea {get;set;}
    [Required]
    public string PhysicalRequirements {get;set;}

}
}