using System;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using dotnetapp.Controllers;
using dotnetapp.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Data
{
    public class ApplicationDbContext:IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options) {}
        public DbSet<PhysicalTraining> PhysicalTrainings{get;set;}

        public DbSet<PhysicalTrainingRequest> PhysicalTrainingRequests{get;set;}

        public DbSet<Feedback> Feedbacks{get;set;}

        public DbSet<User> Users{get;set;}
    }
}