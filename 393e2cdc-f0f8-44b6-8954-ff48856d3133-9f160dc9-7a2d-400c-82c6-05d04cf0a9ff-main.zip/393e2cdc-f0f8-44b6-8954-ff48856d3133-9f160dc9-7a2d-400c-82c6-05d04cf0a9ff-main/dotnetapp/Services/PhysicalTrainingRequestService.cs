using System;
using System.Collections;
using System.Threading.Tasks;
using dotnetapp.Data;
using dotnetapp.Exceptions;
using Microsoft.EntityFrameworkCore;
using dotnetapp.Models;



namespace dotnetapp.Services{
public class PhysicalTrainingRequestService
{
    private readonly ApplicationDbContext _context;

    //Constructor for initializing 
    public PhysicalTrainingRequestService(ApplicationDbContext context)
    {
        _context=context;
    }

    //Retrieves and returns all physical training sessions from the database
    public async Task<IEnumerable<PhysicalTrainingRequest>> GetAllPhysicalTrainingRequests()
    {
        return await _context.PhysicalTrainingRequests.Include(p => p.PhysicalTraining).Include(p => p.User).ToListAsync();
    }

    //Retrieves a physical training session from the database with the specified trainingld. 

    public async Task<IEnumerable<PhysicalTrainingRequest>> GetPhysicalTrainingRequestsByUserId(int userId)
    {
        return await _context.PhysicalTrainingRequests.Where(p => p.UserId == userId).Include(p => p.PhysicalTraining).ToListAsync();
    }

    //Checks if a physical training session with the same training name already exists in the database if not then add training
    public async Task<bool> AddPhysicalTrainingRequest(PhysicalTrainingRequest request)
    {
        // Check if the physical training exists
        bool trainingExists = await _context.PhysicalTrainings.AnyAsync(p => p.PhysicalTrainingId == request.PhysicalTrainingId);
        if (!trainingExists)
        {
            throw new PhysicalTrainingException("The specified physical training does not exist.");
        }

        // Check if user already requested the training
        bool exists =await _context.PhysicalTrainingRequests.AnyAsync(p => p.PhysicalTrainingId  == request.PhysicalTrainingId && p.UserId == request.UserId);
        if(exists)
        {
            throw new PhysicalTrainingException("User already requested this training.");
        }
        _context.PhysicalTrainingRequests.Add(request);
        await _context.SaveChangesAsync();
        return true;
    }
    // If no training with the specified trainingld is found in the database, returns false otherwise update training
    public async Task<bool> UpdatePhysicalTrainingRequest(int requestId,PhysicalTrainingRequest request)
    {
        var existingRequest =await _context.PhysicalTrainingRequests.FindAsync(requestId);
        if(existingRequest == null)
        {
            return false;
        }
        existingRequest.UserId=request.UserId;
        existingRequest.PhysicalTrainingId=request.PhysicalTrainingId;
        existingRequest.RequestDate=request.RequestDate;
        existingRequest.Status=request.Status;
        existingRequest.HealthConditions=request.HealthConditions;
        existingRequest.FitnessGoals=request.FitnessGoals;
        existingRequest.Comments=request.Comments;
        await _context.SaveChangesAsync();
        return true;
    }
    //Retrieves the physical training session from the database based on the provided trainingld  and Delete it
    public async Task<bool> DeletePhysicalTrainingRequest(int requestId)
    {
        var request = await _context.PhysicalTrainingRequests.FindAsync(requestId);
        if(request == null)
        {
            return false;
        }
        _context.PhysicalTrainingRequests.Remove(request);
        await _context.SaveChangesAsync();
        return true;
    }


}
}