using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Controllers;
using dotnetapp.Data;
using dotnetapp.Models;

using Microsoft.EntityFrameworkCore;


namespace dotnetapp.Services{
  public class FeedbackService{
    private readonly ApplicationDbContext _context;

    public FeedbackService(ApplicationDbContext context){
        _context=context;
    }

    //Retrieves all feedbacks from the database
    public async Task<IEnumerable<Feedback>> GetAllFeedbacks(){
        
        return await _context.Feedbacks.Include(f=>f.User).ToListAsync();
    }
    
    // Retrives all feedbacks associated with a specific userId from the database
    public async Task<IEnumerable<Feedback>> GetFeedbacksByUserId(int userId){
         return await  _context.Feedbacks.Where(feedback=> feedback.UserId== userId).ToListAsync();
    }

      // Adds new feedback to the database
    public async Task<bool> AddFeedback(Feedback feedback){
      // Console.WriteLine("Feedback Data:"+feedback);
      if(feedback==null)
      {
        return false;
      }
       await _context.Feedbacks.AddAsync(feedback);
       await _context.SaveChangesAsync();
       return true; 
    }

     // Retrieve the existing feedback from the database with the specified feedbackID
    public async Task<bool> DeleteFeedback(int feedbackId){
     var delete_feedback=await _context.Feedbacks.FindAsync(feedbackId);
     if(delete_feedback==null){
        return false;
     }  
     _context.Feedbacks.Remove(delete_feedback);
     await _context.SaveChangesAsync();
     return true;

    }

}
}