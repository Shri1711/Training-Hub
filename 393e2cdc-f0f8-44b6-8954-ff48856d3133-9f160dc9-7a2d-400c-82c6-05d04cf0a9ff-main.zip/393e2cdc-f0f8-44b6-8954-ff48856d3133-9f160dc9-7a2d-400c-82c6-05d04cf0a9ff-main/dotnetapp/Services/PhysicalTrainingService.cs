using Microsoft.EntityFrameworkCore;
using dotnetapp.Models;
using dotnetapp.Data;
using System.Collections;
using System.IO;
using System;
using dotnetapp.Exceptions;

namespace dotnetapp.Services{
    
    public class PhysicalTrainingService{
    private readonly ApplicationDbContext _context;
    public PhysicalTrainingService(ApplicationDbContext context)
    {
        _context=context;
    }

    // Retrieves and returns all physical training sessions from the database.
    public async Task<IEnumerable<PhysicalTraining>> GetAllPhysicalTrainings()
    {
        var physical_trainings_list=await _context.PhysicalTrainings.ToListAsync();
        return physical_trainings_list;
    }

    // Retrieves a physical training session from the database with the specified trainingId.
    public async Task<PhysicalTraining> GetPhysicalTrainingById(int trainingId)
    {
        var physical_training=await _context.PhysicalTrainings.FirstOrDefaultAsync(pt=>pt.PhysicalTrainingId==trainingId);
        return physical_training;
    }


    // To Save a new Physical training to the database. Checking first if a physical training session with the same name already exist or not.
    public async Task<bool> AddPhysicalTraining(PhysicalTraining training)
    {
        var exist=await _context.PhysicalTrainings.FirstOrDefaultAsync(pt=>pt.TrainingName==training.TrainingName);
        if(exist!=null)
        {
            throw new PhysicalTrainingException("Training with the same name already exists.");
        }
        _context.PhysicalTrainings.Add(training);
        _context.SaveChangesAsync();
        return true;
    }

    // Updating the existing training details
    public async Task<bool> UpdatePhysicalTraining(int trainingId,PhysicalTraining training) //cardio
    {
        var existing_training=await _context.PhysicalTrainings.FirstOrDefaultAsync(pt=>pt.PhysicalTrainingId==trainingId);
        if(existing_training==null)
        {
            return false;
        }
        // Checking if the new training name is different from the existing one
         if (existing_training.TrainingName != training.TrainingName)
        {
            // Checking if a session with the same new name exists
            var exists_name = await _context.PhysicalTrainings.FirstOrDefaultAsync(pt => pt.TrainingName == training.TrainingName);
            if (exists_name != null)
            {
                throw new PhysicalTrainingException("Training with the same name already exists.");
            }
        }
        existing_training.TrainingName=training.TrainingName;
        existing_training.Description=training.Description;
        existing_training.TrainerName=training.TrainerName;
        existing_training.Location=training.Location;
        existing_training.IsIndoor=training.IsIndoor;
        existing_training.Fee=training.Fee;
        existing_training.FocusArea=training.FocusArea;
        existing_training.PhysicalRequirements=training.PhysicalRequirements;
        _context.SaveChangesAsync();
        return true;
    }


    // Removing existing training details from the database, if exists delete
    public async Task<bool> DeletePhysicalTraining(int trainingId)
    {
        var exist_training=_context.PhysicalTrainings.Find(trainingId);
        if(exist_training==null)
        {
            return false;
        }
        // checking if the training session is referenced in any PhysicalTrainingRequest.
        var isReferenced=await _context.PhysicalTrainingRequests.AnyAsync(ptr=>ptr.PhysicalTrainingId==trainingId);
        if(isReferenced)
        {
            throw new PhysicalTrainingException("Training cannot be deleted as it is referenced in a request.");
        }
        _context.PhysicalTrainings.Remove(exist_training);
        _context.SaveChangesAsync();
        return true;
    }
}
}