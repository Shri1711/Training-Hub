using dotnetapp.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using dotnetapp.Data;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks.Sources;
using System.Diagnostics.CodeAnalysis;




namespace dotnetapp.Services
{
    public class AuthService: IAuthService
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly IConfiguration configuration;
        private readonly ApplicationDbContext context;

        public AuthService(UserManager<ApplicationUser> _userManager,RoleManager<IdentityRole> _roleManager,IConfiguration _configuration,ApplicationDbContext _context)
        {
            userManager=_userManager;
            roleManager=_roleManager;
            configuration=_configuration;
            context=_context;
        }


        // User Registration
        public async Task<(int,string)> Registration(User model,string role)
        {
            // Check if the role is either "Admin" or "User"
            if (role != "Admin" && role != "User")
            {
                return (0, "Invalid role. Only 'Admin' and 'User' roles are allowed.");
            }
            var userExists=await userManager.FindByEmailAsync(model.Email);
            if(userExists!=null)
            {
                return (0,"User already exists.");
            }

            ApplicationUser user=new()
            {
                UserName=model.Username,
                SecurityStamp=Guid.NewGuid().ToString(),
                Email=model.Email,
                Name=model.Username.Length>30?model.Username.Substring(0,30):model.Username,
                PhoneNumber=model.MobileNumber
            };

            var result=await userManager.CreateAsync(user,model.Password);
            if(!result.Succeeded)
            {
                return (0,"User creation failed! Please check user details and try again.");
            }

            if(!await roleManager.RoleExistsAsync(role))
            {
                await roleManager.CreateAsync(new IdentityRole(role));
            }

            var newUser = new User
            {
                Email = model.Email,
                Password = model.Password,
                Username = model.Username,
                MobileNumber = model.MobileNumber,
                UserRole = role
            };

            await context.Users.AddAsync(newUser);
            await context.SaveChangesAsync();

            await userManager.AddToRoleAsync(user,role);

            return (1,"User created successfully!");

        }


        //User Login
        public async Task<(int,string)> Login(LoginModel model)
        {
            var user=await userManager.FindByEmailAsync(model.Email);
            if(user==null)
            {
                return (0,"Invalid email");
            }

            if(!await userManager.CheckPasswordAsync(user,model.Password))
            {
                return (0,"Invalid password");
            }

            var customUser=await context.Users.FirstOrDefaultAsync(u=>u.Email==model.Email);
            var authClaims=new List<Claim>
            {
                new(ClaimTypes.Name, user.UserName),
                new Claim(JwtRegisteredClaimNames.Email,user.Email),
                new Claim(ClaimTypes.NameIdentifier,customUser?.UserId.ToString() ?? string.Empty),
                new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            };
            
            // Retrieve the single role for the user
            var userRole = (await userManager.GetRolesAsync(user)).FirstOrDefault();
            if (userRole != null)
            {
                authClaims.Add(new Claim(ClaimTypes.Role, userRole)); // Add the single role as a claim
            }
            var token=GenerateToken(authClaims);
            return (1,token);
        }

        // JWT Token Generation
        private string GenerateToken(IEnumerable<Claim> claims)
        {
            var authSigningKey=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["JWT:Key"]));
            var tokenDescriptor=new SecurityTokenDescriptor{
                Issuer=configuration["JWT:ValidIssuer"],
                Audience=configuration["JWT:ValidAudience"],
                Expires=DateTime.Now.AddHours(3),
                Subject=new ClaimsIdentity(claims),
                SigningCredentials=new SigningCredentials(authSigningKey,SecurityAlgorithms.HmacSha256)
            };
            
            var tokenHandler=new JwtSecurityTokenHandler();
            var token=tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}


