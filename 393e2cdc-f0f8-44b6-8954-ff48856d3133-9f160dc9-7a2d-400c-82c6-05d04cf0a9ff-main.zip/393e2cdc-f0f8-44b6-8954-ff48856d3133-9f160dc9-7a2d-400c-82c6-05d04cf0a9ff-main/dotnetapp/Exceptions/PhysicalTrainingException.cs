using System;


namespace dotnetapp.Exceptions
{
    // Custom Exception
    public class PhysicalTrainingException : Exception
    {
        
        public PhysicalTrainingException(string message) : base(message)
        {}
    }
}